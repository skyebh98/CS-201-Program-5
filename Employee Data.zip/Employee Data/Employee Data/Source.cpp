//Skye Hewitt
//sbhngh@mail.umkc.edu
//04-14-19
//Employee Data Program

#include <iostream>
#include <fstream>
#include <string>
#include "EmployeeClasses.h"

using namespace std;

int main()
{	//Object declarations
	ifstream fin("input.txt");
	ofstream fout("Employees.txt");
	char employeeType;
	int hourlyCount = 0, monthlyCount = 0, totalCount = 0;
	Employee* employeeList[100];

	while (!fin.eof())
	{
		fin >> employeeType;
		switch (employeeType)
		{
		case('H'):
			employeeList[totalCount] = new HourlyEmployee;


			if (!employeeList[totalCount]->ReadData(fin))
			{ //Pointer will not be written to the file or counted if it fails
				delete employeeList[totalCount];
				employeeList[totalCount] = nullptr;
			}
			else
			{	
				++hourlyCount;
				++totalCount;
			}
			break;

		case('M'):
			employeeList[totalCount] = new MonthlyEmployee;
			if (!employeeList[totalCount]->ReadData(fin))
			{//Pointer will not be written to the file or counted if it fails
				delete employeeList[totalCount];
				employeeList[totalCount] = nullptr;
			}
			else
			{
				++monthlyCount;
				++totalCount;
			}
			break;

		default:
			break;
		}
	}

	//Outputting employee counts to the terminal
	cout << "Hourly Employee Count: " << hourlyCount << endl;
	cout << "Monthly Employee Count : " << monthlyCount << endl;


	for (int index = 0; index < totalCount; ++index)
	{//Outputting correct data to "Employees.txt"
		employeeList[index]->WriteData(fout);
		fout << endl;
	}

	//Closing files

	fin.close();
	fout.close();

}