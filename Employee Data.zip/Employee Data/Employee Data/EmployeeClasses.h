#pragma once
#include <string>

using namespace std;

class Employee //Abstract class
{
public:
	//Getters
	string GetName() { return name; }
	string GetID() const { return IDNumber; }
	virtual string GetType() { return "Employee"; }
	//Setters
	void SetName(const string& newName) { name = newName; }
	void SetID(const string& newIDNumber) { IDNumber = newIDNumber; }
	//Other
	Employee();
	virtual bool WriteData(ostream& out) = 0 { return true; }
	virtual bool ReadData(istream& in) = 0 { return true; }
private:
	string name, IDNumber;
};

class HourlyEmployee : public Employee
{
public:
	//Getters
	char GetExpertEmployee() { return experienceLevel; }
	double GetSalary() { return salary; }
	string GetType() { return "Hourly Employee"; }
	//Setters
	bool SetExpertEmployee(char newExpert);
	bool SetSalary(double newSalary);
	//Other
	HourlyEmployee();
	virtual bool WriteData(ostream& out);
	virtual bool ReadData(istream& in);
private:
	char experienceLevel;
	double salary;
};

class MonthlyEmployee : public Employee
{
public:
	//Getters
	int GetRank() { return rank; }
	string GetType() { return "Monthly Employee"; }
	//Setters
	bool SetRank(int newRank);
	//Other
	MonthlyEmployee();
	virtual bool WriteData(ostream& out);
	virtual bool ReadData(istream& in);
private:
	int rank;
};
