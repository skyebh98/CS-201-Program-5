#include "EmployeeClasses.h"

using namespace std;

//Employee Base Class function definitions
//An abstract class

Employee::Employee()
{ //Constructor
	name = "";
	IDNumber = "";
}

//Hourly Employee function definitions

HourlyEmployee::HourlyEmployee() 
{ //Constructor
	experienceLevel = 'F';
	salary = 0;
}

bool HourlyEmployee::SetExpertEmployee(char newExpert)
{ //Only accepts 'T' or 'F' chars
	if (newExpert == 'T' || newExpert == 'F')
	{
		experienceLevel = newExpert;
		return true;
	}
	else
	{
		return false;
	}
}

bool HourlyEmployee::SetSalary(double newSalary)
{ // Salary must be double >= 1000 and <= 10000. Other values ignored.
  // returns true if parameter is accepted, returns false otherwise.
	if (newSalary >= 1000 && newSalary <= 10000)
	{
		salary = newSalary;
		return true;
	}
	return false;
}

bool HourlyEmployee::ReadData(istream& in)
{//Returns true if correct data types are inputted
	string newName, newIDNumber;
	char newExpert;
	double newSalary;

	in.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

	getline(in, newName);
	SetName(newName);

	getline(in, newIDNumber);
	SetID(newIDNumber);

	in >> newExpert;
	SetExpertEmployee(newExpert);

	in >> newSalary;
	SetSalary(newSalary);

	return in.good();

}

bool HourlyEmployee::WriteData(ostream& out)
{//Returns true if all is outputted correctly
	out << "Hourly Employee" << endl;
	out << GetName() << endl;
	out << GetID() << endl;
	if (GetExpertEmployee() == 'T')
		out << "Expert" << endl;
	else
		out << "Not an Expert" << endl;
	out << "$" << GetSalary() << endl;
	return out.good();
}

//Montly Employee function definitions

MonthlyEmployee::MonthlyEmployee()
{
	rank = 10;
}

bool MonthlyEmployee::SetRank(int newRank)
{
	if (newRank <= 1 && newRank >= 10) {
		return true;
	}
	return false;
}


bool MonthlyEmployee::ReadData(istream& in)
{
	string newName, newIDNumber;
	int newRank;

	in.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	
	getline(in, newName);
	SetName(newName);

	getline(in, newIDNumber);
	SetID(newIDNumber);

	in >> newRank;
	SetRank(newRank);
	return in.good();

}
bool MonthlyEmployee::WriteData(ostream& out)
{
	out << "Hourly Employee" << endl;
	out << GetName() << endl;
	out << GetID() << endl;
	out << GetRank() << endl;
	return out.good();
}